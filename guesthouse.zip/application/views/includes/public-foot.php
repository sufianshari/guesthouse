

<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>


<script type="text/javascript">
    $('.carousel').carousel({
        interval: 3000
    });



    baguetteBox.run('.tz-gallery');
</script>

