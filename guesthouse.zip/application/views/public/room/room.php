<section class="section-header page-title title-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-xs-12">
                <h1>Room</h1>
            </div>
        </div>
    </div>
</section>